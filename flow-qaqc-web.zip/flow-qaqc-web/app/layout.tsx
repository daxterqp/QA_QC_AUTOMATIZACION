import type { Metadata } from 'next'
import './globals.css'
import NavBar from './components/NavBar'

export const metadata: Metadata = {
  title: 'Flow-QA/QC — Sistema Digital de Calidad en Obra',
  description: 'Gestión Digital Integral de QA/QC para proyectos de construcción. Cero papel, trazabilidad absoluta.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body style={{ margin: 0, padding: 0, background: '#0A1929' }}>
        <NavBar />
        <main>{children}</main>
      </body>
    </html>
  )
}
